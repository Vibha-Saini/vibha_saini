package vibha.com.firstProject;

import rs.B;

/**
 * Hello world!
 *
 */
public class App {
	B b = new B();

	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
}
