package rs;

public class B {

}
